-----------------------------------------------------------------

 Atari800 Games Loader prepared by GamesNostalgia.com

 If you like what we do, support us on Patreon:
 
 	https://www.patreon.com/gamesnostalgia
 	
 or with a donation:

	http://gamesnostalgia.com/donate
 
-----------------------------------------------------------------

 USEFUL KEYS:

	F1 Built in user interface
	F2 Option key
	F3 Select key
	F4 Start key
	F5 Reset key ("warm reset")
	Shift+F5 Reboot ("cold reset")
	F6 Help key (XL/XE only)
	F7 Break key
	F8 Enter monitor
	F9 Exit emulator
	F10 Save screenshot
	Shift+F10 Save interlaced screenshot
	Alt+R Run Atari program
	Alt+D Disk management
	Alt+C Cartridge management
	Alt+Y Select system
	Alt+O Sound settings
	Alt+W Sound recording start/stop
	Alt+S Save state file
	Alt+L Load state file
	Alt+A About the emulator

	Keyboard joystick 0: NUMPAD

	right control = fire.

	Keyboard joystick 1
	q w e
	\ | /
	a s d
	/ | \
	z x c
	Tab = fire.

-----------------------------------------------------------------

 Thanks to Atari800 https://atari800.github.io/ for the emulator

 Please go to http://gamesnostalgia.com for more retrogames
 
-----------------------------------------------------------------